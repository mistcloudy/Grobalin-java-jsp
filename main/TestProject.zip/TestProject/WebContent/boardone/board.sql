
create table board(
num number(7) not null,
writer varchar2(12) not null, --작성자
email varchar2(30) not null, --이메일
subject varchar2(50) not null, --제목
pass varchar2(10) not null, --비밀번호
readcount number(5) default 0 not null, --조회수
ref number(5) default 0 not null, --댓글,답변(원본글 num의 번호-> 댓글의ref번호)
step number(3) default 0 not null, -- step 중 가장 큰 수== 댓글의 총 갯수
depth number(3) default 0 not null, -- 깊이(본문==0, 본문에 달린 댓글==1, 본문에 달린 댓글에 달린 댓글==2...)
regdate timestamp (6) default sysdate not null, -- 날짜
content varchar2(4000) not null, --내용
ip varchar2(20) not null, /* */
constraint board_pk primary key(num)
);

create sequence board_seq
start with 1
increment by 1
nomaxvalue
nocache
nocycle;

select * from board;