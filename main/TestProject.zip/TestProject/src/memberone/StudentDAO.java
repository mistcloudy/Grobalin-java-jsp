package memberone;

import java.sql.*;
import java.util.Vector;

import javax.sql.*;

import javax.naming.*;

public class StudentDAO {

	private Connection getConnection() {

		Connection con = null;

		try {
			Context init = new InitialContext();
			DataSource ds = (DataSource) init.lookup("java:comp/env/jdbc/TestProject");
			con = ds.getConnection();
		} catch (Exception e) {
			System.out.println("Connection 연결 실패!!!!!!!!!!!!!!!!!!");
		}
		return con;
	}

	// 메소드 추가 구현
	// id처리하는 메소드
	public boolean idCheck(String id) {
		boolean result = true;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = getConnection();
			// 현재 id값이 뭐가 들어올지 모르므로 ?
			pstmt = con.prepareStatement("select * from student where id=?");
			pstmt.setString(1, id);
			// 조회하는 커리, db의 변화 없는 경우<->db변화가 있는 경우는 .executeUpdate();
			rs = pstmt.executeQuery();

			if (!rs.next())
				result = false;
		} catch (SQLException s1) {
			s1.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ss) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ss) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ss) {
				}
		}
		return result;
	}
	// end idCheck

	// 우편 번호를 데이터베이스에서 검색해서 Vector에 저장해서 리턴해줌
	// 리턴해주는 메소드 추가
	public Vector<ZipcodeVO> zipcodeRead(String dong) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		Vector<ZipcodeVO> vecList = new Vector<ZipcodeVO>();

		try {
			con = getConnection();
			String strQuery = "select * from zipcode where dong like '" + dong + "%'";
			pstmt = con.prepareStatement(strQuery);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ZipcodeVO tempZipcode = new ZipcodeVO();

				tempZipcode.setZipcode(rs.getString("zipcode"));
				tempZipcode.setSido(rs.getString("sido"));
				tempZipcode.setGugun(rs.getString("gugun"));
				tempZipcode.setDong(rs.getString("dong"));
				tempZipcode.setRi(rs.getString("ri"));
				tempZipcode.setBunji(rs.getString("bunji"));

				vecList.addElement(tempZipcode);
			}
		} catch (SQLException s1) {
			s1.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ss) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ss) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ss) {
				}
		}
		return vecList;
	}
	// end zipcodeRead;

	// 회원가입 처리
	// 데이터베이스에 student 테이블에 데이터 추가하는 메소드 구현
	public boolean memberInsert(StudentVO vo) {
		boolean flag = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		// ResultSet rs = null;

		try {
			// DB연결
			con = getConnection();
			String strQuery = "insert into student values(?,?,?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPass());
			pstmt.setString(3, vo.getName());
			pstmt.setString(4, vo.getPhone1());
			pstmt.setString(5, vo.getPhone2());
			pstmt.setString(6, vo.getPhone3());
			pstmt.setString(7, vo.getEmail());
			pstmt.setString(8, vo.getZipcode());
			pstmt.setString(9, vo.getAddress1());
			pstmt.setString(10, vo.getAddress2());
			// DB 추가로 인해 변경되므로 update메소드
			int count = pstmt.executeUpdate();// insert,update,delete
			// executeQuery(); ->select
			if (count > 0)
				flag = true;
		} catch (SQLException s1) {
			s1.printStackTrace();
		} finally {
			// if(rs != null) try {rs.close();}catch(SQLException ss) {}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ss) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ss) {
				}
		}
		return flag;
	}

	// 로그인 버튼을 클릭하면 우리가 입력한 id와 pass를 데이터베이스에 있는 id와 pass를 비교해서 같으면 로그인성공,다르면 로그인 실패
	// 1:로그인성공, 0:비밀번호 오류, -1:아이디 없음
	public int loginCheck(String id, String pass) {

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int check = -1;

		try {
			con = getConnection();
			String strQuery = "select pass from student where id = ?";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				String dbPass = rs.getString("pass"); // 데이터베이스에서 가져온 비밀번호
				if (pass.equals(dbPass))
					check = 1;
				else
					check = 0;
			}

		} catch (SQLException s1) {
			s1.printStackTrace();
		} finally {
			// if(rs!=null)try {rs.close();}catch(SQLException ss) {}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ss) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ss) {
				}
		}
		return check;
	}
//end loginCheck

//DB로부터 지정한 id의 회원정보를 가져오는 메소드
	public StudentVO getMemebr(String id) {
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StudentVO vo = null;
		
		try {
			con=getConnection();
			pstmt=con.prepareStatement("select * from student where id=?");
			//바인딩 ?부분 처리
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			//해당 id 존재의 유무 확인
			if(rs.next()) {
				vo = new StudentVO();
				vo.setId(rs.getString("id"));
				vo.setPass(rs.getString("pass"));
				vo.setName(rs.getString("name"));
				vo.setPhone1(rs.getString("phone1"));
				vo.setPhone2(rs.getString("phone2"));
				vo.setPhone3(rs.getString("phone3"));
				vo.setEmail(rs.getString("email"));
				vo.setZipcode(rs.getString("zipcode"));
				vo.setAddress1(rs.getString("address1"));
				vo.setAddress2(rs.getString("address2"));
			}
		} catch (SQLException s1) {
			s1.printStackTrace();
		} finally {
			 if(rs!=null)try {rs.close();}catch(SQLException ss) {}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ss) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ss) {
				}
		}
		return vo;	
	}//end getMember;
	
	//정보 수정버튼을 클릭했을때 데이터베이스에 update를 수행함
	//정보를 수정처리할 메소드 구현
	public void updateMember(StudentVO vo) {
		
		Connection con=null;
		PreparedStatement pstmt=null;
		try {
			con=getConnection();
			String strQuery="update student set pass=?, phone1=?, phone2=?, phone3=?, "
					+ "email=?, zipcode=?, address1=?, address2=? where id=?";
			pstmt=con.prepareStatement(strQuery);
			pstmt.setString(1, vo.getPass());
			pstmt.setString(2, vo.getPhone1());
			pstmt.setString(3, vo.getPhone2());
			pstmt.setString(4, vo.getPhone3());
			pstmt.setString(5, vo.getEmail());
			pstmt.setString(6, vo.getZipcode());
			pstmt.setString(7, vo.getAddress1());
			pstmt.setString(8, vo.getAddress2());
			pstmt.setString(9, vo.getId());
			
			pstmt.executeUpdate();
		} catch (SQLException s1) {
			s1.printStackTrace();
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ss) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ss) {
				}
		}//end updateMember
		
	
		
	}
	//회원탈퇴 버튼을 클릭하면 회원의 비밀번호를 입력받앗어 데이터베이스의 비밀번화와 일치하는지를 비교
	//일치한다면 회원 탈퇴 처리가 완료, 그렇지 않으면 비밀번호가 틀렸다고 알려줌;
	public int deleteMember(String id, String pass) {

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String dbPass="";
		int result = -1;

		try {
			con = getConnection();
			String strQuery = "select pass from student where id = ?";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				dbPass = rs.getString("pass"); // 데이터베이스에서 가져온 비밀번호
				if (dbPass.equals(pass)) {
					pstmt=con.prepareStatement("delete from student where id=?");
					pstmt.setString(1, id);
					pstmt.executeUpdate();
					result=1;//회원 탈퇴성공
				}else //본인 확인 실패-비밀번호 오류
					result = 0;
			}

		} catch (SQLException s1) {
			s1.printStackTrace();
		} finally {
			// if(rs!=null)try {rs.close();}catch(SQLException ss) {}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ss) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ss) {
				}
		}
		return result;
	}
	
}